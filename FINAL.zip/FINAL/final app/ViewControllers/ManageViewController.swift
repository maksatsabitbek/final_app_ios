//
//  ManageBookViewController.swift
//  Created by Mac on 12/6/2021.


import Foundation
import UIKit
import Firebase
import FirebaseAuth

class ManageViewController: UIViewController {
    
    @IBOutlet weak var manageBookTable: UITableView!
    
//    var bookISBN = ""
    
    var filteredBooks: [meat]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 13.0, *) {
                // Always adopt a light interface style.
                overrideUserInterfaceStyle = .light
        }
        
        manageBookTable.delegate = self
        manageBookTable.dataSource = self
        getBooks()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    var meatList = [meat]()
    
    // get all the books from database
    // and shows the ones listed by the current user
    func getBooks(){
        let user = Auth.auth().currentUser;
        let db = Firestore.firestore()
        let docRef = db.collection("books")
        docRef.getDocuments { (snapshot, err) in
            if err != nil{
                print("error in accessing data")
            }else{
                
                for item in snapshot!.documents{
                    if item.data()["uid"] as! String != user!.uid {
                        continue
                    }
    
                    var image = ""
                    if item.data()["image"] == nil{
                        image = "defualt"
                    }else{
                        image = item.data()["image"] as! String
                    }
                    let newBook = meat(title: item.data()["title"] as! String, isbn: item.data()["isbn"] as! String, imageName: image, condition: item.data()["condition"]as! String, price: item.data()["price"] as! String, docID: item.documentID)

                    self.meatList.append(newBook)
                }
                
            }
            self.manageBookTable.reloadData()
        }
    }
}

// let the user interacts with the page
extension ManageViewController:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("tapped")
        
        // Go to the book Modification page
        let thisBook: meat!
        thisBook = meatList[indexPath.row]
        
//        self.bookISBN = thisBook.isbn
        
        performSegue(withIdentifier: "editBook", sender: self)
        
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        let vc = segue.destination as! EditBookViewController
////        vc.bookISBN = self.bookISBN
//
//    }
}

// update the data for table rows
extension ManageViewController:UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meatList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableVC = tableView.dequeueReusableCell(withIdentifier: "tableVCID", for: indexPath) as! tableViewCell
        
        let thisMeat: meat!

        thisMeat = meatList[indexPath.row]
        tableVC.adTitle.alpha = 1
        tableVC.adTitle.text = thisMeat.title

        tableVC.Description.alpha = 1
        tableVC.Description.text = "Price" + thisMeat.price

        tableVC.adImage.image = UIImage (named: thisMeat.imageName)
        
        return tableVC
    }
}
