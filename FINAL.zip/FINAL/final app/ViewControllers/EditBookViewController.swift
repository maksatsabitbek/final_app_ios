//
//  EditBookViewController.swift
//  cmpe131//  Created by Mac on 12/6/2021.


import Foundation
import UIKit
import Firebase
import FirebaseAuth

class EditBookViewController: UIViewController {
    
    @IBOutlet weak var adTitleTextField: UITextField!
    
    @IBOutlet weak var descTextField: UITextField!
    
    @IBOutlet weak var dateTextField: UITextField!
    
//    @IBOutlet weak var bookISBNTextField: UITextField!
    
//    @IBOutlet weak var bookConditionTextField: UITextField!
    
    @IBOutlet weak var priceTextField: UITextField!
    
    @IBOutlet weak var updateButton: UIButton!
    
    var adTitle = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 13.0, *) {
                // Always adopt a light interface style.
                overrideUserInterfaceStyle = .light
        }
    
        // Need to call function
        let db = Firestore.firestore()
        let user = Auth.auth().currentUser
        
        let docRef = db.collection("books")
        
        // get information from database for current selected book
        docRef.getDocuments { (snapshot, err) in
            if err != nil{
                print("error in accessing data")
            }else{
                
                for item in snapshot!.documents{
                    if item.data()["uid"] as! String == user!.uid && item.data()["title"] as! String == self.adTitle{
                        self.adTitleTextField.text = item.data()["title"] as? String
                        self.descTextField.text = item.data()["desc"] as? String
                        self.dateTextField.text = item.data()["date"] as? String
//                        self.bookISBNTextField.text = item.data()["isbn"] as? String
//                        self.bookConditionTextField.text = item.data()["condition"] as? String
                        self.priceTextField.text = item.data()["price"] as? String
                        break
                    }
                }
                
            }
            
        }
        self.setUpElements()
    }
    
    func setUpElements(){
        Utilities.fillButton(button: updateButton)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // save the updated book details to data base
    @IBAction func updateTapped(_ sender: Any) {
        let BT = adTitleTextField.text!
        let BAuthor = descTextField.text!
        let BYear = dateTextField.text!
//        let ISBN = bookISBNTextField.text!
//        let BCond = bookConditionTextField.text!
        let BPrice = priceTextField.text!
        
        let db = Firestore.firestore()
        
        let user = Auth.auth().currentUser
        
        db.collection("meats").document(self.adTitle).updateData([
            "title": BT,
            "author": BAuthor,
            "year": BYear,
//            "isbn": ISBN,
//            "condition": BCond,
            "price": BPrice,
            "uid": user!.uid,
            "image": "no_image"
        ])
        
        self.transitToSuccessPage()
    }
    
    func transitToSuccessPage() {
        let listSuccessViewController = storyboard?.instantiateViewController(identifier: Constants.Storyboard.listSuccessViewController)
        
        view.window?.rootViewController = listSuccessViewController
        view.window?.makeKeyAndVisible()
    }
    
}
