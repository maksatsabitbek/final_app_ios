//
//  appTabBarController.swift
//  Created by Mac on 12/6/2021.


import UIKit

class appTabBarController: UITabBarController{
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
