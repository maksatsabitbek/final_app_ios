//
//  forSaleViewController.swift
//  Created by Mac on 12/6/2021.


import UIKit
import Firebase

class forSaleViewController: UIViewController{
    
    
    @IBOutlet weak var adTitle: UILabel!
    
    @IBOutlet weak var adImage: UIImageView!
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var purchaseButton: UIButton!
    
    

    var selectedMeat: meat!
    
    @IBOutlet weak var sellerTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 13.0, *) {
                // Always adopt a light interface style.
                overrideUserInterfaceStyle = .light
            }
        getSellers()
        setUpElement()
    }
    
    func setUpElement(){
        Utilities.fillButton(button: purchaseButton)
    }
    func getSellers(){
        adTitle.text = selectedMeat.title
        adImage.image = UIImage (named: selectedMeat.imageName)
        conditionLabel.text = "Condition: " + selectedMeat.condition
        priceLabel.text = "Price: $" + selectedMeat.price
            
    }
    
    
    func transitToPurchaseSuccess() {
        let pSuccess = storyboard?.instantiateViewController(identifier: Constants.Storyboard.purchaseSuccessful) as? purchaseSuccessful
        view.window?.rootViewController = pSuccess
        view.window?.makeKeyAndVisible()
    }
    
    @IBAction func purchaseButtonTapped(_ sender: Any) {
        let db = Firestore.firestore()
        db.collection("books").document(selectedMeat.docID).delete()
        transitToPurchaseSuccess()
    }
}
