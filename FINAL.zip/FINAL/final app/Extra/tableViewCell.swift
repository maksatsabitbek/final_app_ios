//
//  tableViewCell.swift
//  Created by Mac on 12/6/2021.


import Foundation
import UIKit

class tableViewCell : UITableViewCell{
    
    @IBOutlet weak var adTitle: UILabel!
    @IBOutlet weak var Description: UILabel!
    @IBOutlet weak var adImage: UIImageView!
    
}
