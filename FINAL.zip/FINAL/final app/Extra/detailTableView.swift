//
//  detialTableView.swift
//  Created by Mac on 12/6/2021.


import UIKit

class detailTableView: UITableViewCell{
    
    @IBOutlet weak var bookTitle: UILabel!
    @IBOutlet weak var bookQuality: UILabel!
    
}
