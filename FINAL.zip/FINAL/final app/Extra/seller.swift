//
//  seller.swift
//  Created by Mac on 12/6/2021.


import Foundation

class seller{
    var title: String!
    var quality: String!
    var price: String!
    var email: String!
    
    public init(title: String, quality: String, price: String, email:String){
        self.title = title
        self.quality = quality
        self.price = price
        self.email = email
    }
}
