//
//  NewTableViewCell.swift
//  Created by Mac on 12/6/2021.


import UIKit

class NewTableViewCell: UITableViewCell {
    
    @IBOutlet weak var meatDescription: UILabel!
    @IBOutlet weak var adTitle: UILabel!
    @IBOutlet weak var addToCart: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
